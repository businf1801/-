from __future__ import annotations

import typing as tp

import aioredis


class RedisDatabase:
    def __init__(self, pool: aioredis.Redis):
        self.pool = pool

    @staticmethod
    async def create(number: int) -> RedisDatabase:
        pool = await aioredis.create_redis_pool('redis://localhost', db=number)
        return RedisDatabase(pool)

    async def get_value(self, key) -> tp.Any:
        value = await self.pool.lindex(key, 0)
        return value

    async def set_value(self, key, value) -> None:
        await self.pool.lpush(key, value)

    async def delete_value(self, key) -> None:
        await self.pool.lpop(key)
