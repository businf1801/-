import asyncio
import logging
import os

import aiograph
from aiogram import Bot, Dispatcher, executor, types
from aiogram.contrib.fsm_storage.redis import RedisStorage2
from aiogram.dispatcher import FSMContext
from dotenv import load_dotenv

from parser import Film, Parser
from redis_database import RedisDatabase
from states import States

load_dotenv()

bot = Bot(token=os.environ['BOT_TOKEN'])


logging.basicConfig(level=logging.INFO)
storage = RedisStorage2(db=5)
dp = Dispatcher(bot, storage=storage)
telegraph = aiograph.Telegraph()
database_watched = asyncio.get_event_loop().run_until_complete(RedisDatabase.create(1))
database_planning = asyncio.get_event_loop().run_until_complete(RedisDatabase.create(2))
telegraph_database = asyncio.get_event_loop().run_until_complete(RedisDatabase.create(3))


@dp.message_handler(commands=['start'])
async def start(message: types.Message, state: FSMContext) -> None:
    await state.set_state(States.STATE_NONE)
    await bot.send_message(message.chat.id, 'Hello! \n If you want to find film enter it title.')


@dp.message_handler(commands=['help'])
async def help(message: types.Message, state: FSMContext) -> None:
    await state.set_state(States.STATE_NONE)
    await bot.send_message(message.chat.id, 'If you want to find film enter it title.')


@dp.message_handler(state='*', commands=['add_watched'])
async def add_watched(message: types.Message, state: FSMContext) -> None:
    await state.set_state(States.STATE_ADD_WATCHED)
    await bot.send_message(message.chat.id, 'Enter film name, year and mark')
    logging.info(await state.get_state())


@dp.message_handler(state='*', commands=['add_planning'])
async def add_planning(message: types.Message, state: FSMContext) -> None:
    await state.set_state(States.STATE_ADD_PLANNING)
    await bot.send_message(message.chat.id, 'Enter film name and year')
    logging.info(await state.get_state())


@dp.message_handler(state='*', commands=['find_by_name'])
async def find_film_by_name(message: types.Message, state: FSMContext) -> None:
    await state.set_state(States.STATE_FIND_FILM_BY_NAME)
    await bot.send_message(message.chat.id, 'Enter film name')
    logging.info(await state.get_state())


@dp.message_handler(state='*', commands=['find_similar'])
async def add_watched(message: types.Message, state: FSMContext) -> None:
    await state.set_state(States.STATE_FIND_SIMILAR_FILM)
    await bot.send_message(message.chat.id, 'Enter film name and year')
    logging.info(await state.get_state())


@dp.message_handler(state='*', commands=['get_state'])
async def get_state(message: types.Message, state: FSMContext) -> None:
    logging.info(await state.get_state())


@dp.message_handler(lambda q: True, state=States.STATE_ADD_WATCHED)
async def handler_watched(message: types.Message, state: FSMContext) -> None:
    logging.info(dp.current_state(user=message.from_user.id))
    film_name, year, mark = message.text.split()
    film = '{}_{}'.format(film_name, year)
    if await database_planning.get_value(film):
        await database_planning.delete_value(film)
    await database_watched.set_value(film, mark)
    await state.set_state(States.STATE_NONE)


@dp.message_handler(state=States.STATE_ADD_PLANNING)
async def handler_planning(message: types.Message, state: FSMContext) -> None:
    logging.info(dp.current_state(user=message.from_user.id))
    film_name, year = message.text.split()
    film = '{}_{}'.format(film_name, year)
    await database_planning.set_value(film, None)
    await state.set_state(States.STATE_NONE)


@dp.callback_query_handler(state=States.STATE_FIND_FILM_BY_NAME)
async def handler_find_by_name(message: types.Message, state: FSMContext) -> None:
    logging.info(dp.current_state(user=message.from_user.id))
    parser = Parser()
    film_name = message.text
    logging.info(film_name)
    films = await parser.search_film(film_name)
    if not films:
        await bot.send_message(message.from_user.id, 'Film was not found')
    else:
        with open('film_page.html') as page_file:
            html_template = page_file.read()
        logging.info(films)
        await telegraph.create_account("films")
        for film in films:
            if isinstance(film, Film):
                film_code = '{}_{}'.format(film.film_dict['title'], film.film_dict['year'])
                if await database_watched.get_value(film_code):
                    continue
                telegraph_link = await telegraph_database.get_value(film.film_link)
                if not telegraph_link:
                    logging.info('Generate page')
                    picture = await telegraph.upload_from_url(film.film_dict['picture_link'])
                    film_html = html_template.format(picture=picture, **film.film_dict)
                    page = await telegraph.create_page(film.film_dict['title'], film_html)
                    telegraph_link = page.url
                    await telegraph_database.set_value(film.film_link, page.url)
                else:
                    telegraph_link = telegraph_link.decode('utf-8')
                await bot.send_message(message.from_user.id, telegraph_link)
    await state.set_state(States.STATE_NONE)
    await parser.session.close()

@dp.callback_query_handler(state=States.STATE_FIND_SIMILAR_FILM)
async def handler_find_similar(message: types.Message, state: FSMContext) -> None:
    logging.info(dp.current_state(user=message.from_user.id))
    parser = Parser()
    film_name, year = message.text.split()
    films = await parser.search_film(film_name)
    search_film = None
    if not films:
        await bot.send_message(message.from_user.id, 'Film was not found')
    else:
        logging.info(films)
        await telegraph.create_account("films")
        for film in films:
            if isinstance(film, Film):
                if film.film_dict['year'] == year:
                    search_film = film
                    break
    if search_film is not None:
        with open('film_page.html') as page_file:
            html_template = page_file.read()
        for film in search_film.get_similar():
            await parser.parse_film(film)
            film_code = '{}_{}'.format(film.film_dict['title'], film.film_dict['year'])
            if await database_watched.get_value(film_code):
                continue
            telegraph_link = await telegraph_database.get_value(film.film_link)
            if not telegraph_link:
                logging.info('Generate page')
                picture = await telegraph.upload_from_url(film.film_dict['picture_link'])
                film_html = html_template.format(picture=picture, **film.film_dict)
                page = await telegraph.create_page(film.film_dict['title'], film_html)
                telegraph_link = page.url
                await telegraph_database.set_value(film.film_link, page.url)
            else:
                telegraph_link = telegraph_link.decode('utf-8')
            await bot.send_message(message.from_user.id, telegraph_link)
    await state.set_state(States.STATE_NONE)
    await parser.session.close()


@dp.message_handler(state='*')
async def handler(message, state):
    state_string = await state.get_state()
    state_string = state_string.replace('[', '').replace(']', '').replace("'", '')
    if state_string == States.STATE_ADD_WATCHED[0]:
        await handler_watched(message, state)
    elif state_string == States.STATE_ADD_PLANNING[0]:
        await handler_planning(message, state)
    elif state_string == States.STATE_FIND_FILM_BY_NAME[0]:
        await handler_find_by_name(message, state)
    elif state_string == States.STATE_FIND_SIMILAR_FILM[0]:
        await handler_find_similar(message, state)


if __name__ == '__main__':
    executor.start_polling(dp, skip_updates=True)
