from __future__ import annotations


import asyncio
import typing as tp
from abc import ABC, abstractmethod

from aiohttp import ClientSession
from bs4 import BeautifulSoup



class Film:
    def __init__(self, film_link: str, picture_link: str) -> None:
        self.film_link = film_link
        self.picture_link = picture_link
        self.film_dict: tp.Dict[str, str] = {}
        self.html_code = ''
        self.base_url = 'https://ivi.ru'

    def __call__(self, html_code: str) -> Film:
        soup = BeautifulSoup(html_code, 'lxml')
        self.html_code = html_code
        parameters_info = soup.select('.parameters__info > .link.parameters__link')
        self.film_dict['film_link'] = self.film_link
        self.film_dict['title'] = soup.select('.breadCrumbs.headerBar__breadCrumbs span')[-1].text
        self.film_dict['picture_link'] = self.picture_link
        self.film_dict['year'] = parameters_info[0].text
        self.film_dict['country'] = parameters_info[1].text
        self.film_dict['genres'] = ', '.join(info.text for info in parameters_info[2:])
        self.film_dict['description'] = soup.select_one('.details__informationArticle').text
        return self

    def get_similar(self):
        soup = BeautifulSoup(self.html_code, 'lxml')
        similar_films_soup = soup.select('.gallery__viewport-inner > .gallery__list')[-2]
        similar_films = []
        for link in similar_films_soup.select('a'):
            film_link = link['href']
            picture_link, _, _ = link.select_one('img')['src'].rsplit('/', 2)
            picture_link = f'{picture_link}/480x720/'
            similar_films.append(Film(f'{self.base_url}{film_link}', picture_link))
        return similar_films


class Parser:
    def __init__(self) -> None:
        self.session = ClientSession(
            headers={"User-Agent": "Mozilla/5.001 (windows; U; NT4.0; en-US; rv:1.0) Gecko/25250101"}
        )
        self.base_url = 'https://ivi.ru'
        self.search_suffix = '/search/'

    async def parse_film(self, film: Film) -> Film:
        async with self.session.get(film.film_link) as response:
            return film(await response.text())

    def get_films_list(self, html_code: str) -> tp.List[Film]:
        soup = BeautifulSoup(html_code, 'lxml')
        films_list: tp.List[Film] = []
        for link in soup.select('.gallery-wrapper li'):
            link = link.select_one('a')
            film_link = link['href']
            picture_link, _, _ = link.select_one('img')['src'].rsplit('/', 2)
            films_list.append(Film(f'{self.base_url}{film_link}', f'{picture_link}/480x720/'))
        return films_list

    async def search_film(self, request_string: str) -> tp.List[Film]:
        url = f'{self.base_url}{self.search_suffix}'
        async with self.session.get(url, params={'q': request_string}) as response:
            films = self.get_films_list(await response.text())
            coroutines_list = [self.parse_film(film) for film in films]
            return await asyncio.gather(*coroutines_list, return_exceptions=True)


async def main() -> None:
    request_string = 'Мстители'
    ivi_parser = Parser()
    films = await ivi_parser.search_film(request_string)
    print(*((film.film_dict['title'], film.film_dict['film_link']) for film in films), sep='\n')


if __name__ == '__main__':
    asyncio.run(main())
