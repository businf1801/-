from aiogram.utils.helper import Helper, HelperMode, ListItem


class States(Helper):
    mode = HelperMode.snake_case

    STATE_ADD_WATCHED = ListItem()
    STATE_ADD_PLANNING = ListItem()
    STATE_FIND_FILM_BY_NAME = ListItem()
    STATE_FIND_SIMILAR_FILM = ListItem()
    STATE_NONE = ListItem()


if __name__ == '__main__':
    print(States.STATE_FIND_SIMILAR_FILM)
    print(States.all())
